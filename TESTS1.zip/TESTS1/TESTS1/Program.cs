﻿using System; // Pour Console.WriteLine

namespace ProgrammationJeuxVideo1
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Début de l'exécution du projet " + "TESTS1");
			TESTS1 app = new TESTS1();
			app.Run();
			Console.WriteLine("Fin de l'exécution du projet " + "TESTS1");
		}
	}
}
